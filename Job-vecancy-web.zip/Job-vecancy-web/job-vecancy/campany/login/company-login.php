<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
    <link rel="stylesheet" href="company-login.css">  
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

                 
    <?php
                    $msg1="";
                    $msg2="";

            if(isset($_POST['sent'])){

                // registration form
                if($_POST['sent']=="REGISTER"){
                    // user name validation
                    $_POST['name'] = htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8');
                    if(empty($_POST['name'])) $msg1.="Your name cannot be empty <br>";

                    // email validation
                    $_POST['gmail'] = trim($_POST['gmail']);
                    if(empty($_POST['gmail'])) $msg1.="Email cannot be empty <br>";
                    elseif(!filter_var($_POST['gmail'],FILTER_VALIDATE_EMAIL)) $msg1.="Email address it not valid <br>";

                    // password validation
                    if(empty($_POST['password']) || empty($_POST['password2'])) $msg1.="Passwords cannot be empty <br>";
                    elseif($_POST['password']!=$_POST['password2']) $msg1.="Passwords do not match <br>";
                    

                    // db operations
                    if($msg1==""){
                        try {
                            // connect to db
                            include "../../database.php";
    
                            // check for existing email
                            $check = $db->prepare("SELECT `id` FROM `company_login` WHERE `email`=?");
                            $check->execute(array($_POST['gmail']));
    
                            if($check->rowCount()>0) {
                            $msg1.="Email address you entered is registered already(php)<br>";
                            }
                            else{
                                // insert user
                                $pwd = password_hash($_POST['password'],PASSWORD_DEFAULT);
                                
                                $ok = $db->prepare("INSERT INTO `company_login` (`username`, `email`, `password`) VALUES (?,?,?)")->execute(array($_POST['name'], $_POST['gmail'], $pwd));

                                $okmsg1 = "Record is added successfully";

                            }

                        }catch (PDOException $e){
                            $msg.=$e->getMessage();
                            echo $e;
                        }

                    }

                    
                }

                // login form
                elseif($_POST['sent']=="Sign In"){
                    // email validation
                    $_POST['login_email'] = trim($_POST['login_email']);
                    if(empty($_POST['login_email'])) $msg2.="Email cannot be empty <br>";
                    elseif(!filter_var($_POST['login_email'],FILTER_VALIDATE_EMAIL)) $msg.="Email address it not valid (php**)<br>";
    
                    // password validation
                    if(empty($_POST['login_password'])) 
                    $msg2.="Password cannot be empty <br>";
    
                    // db operations
                    //if(true){
                    if($msg2==""){
                        try{
                            //connect to db
                            include "../../database.php";
    
                            // check for a registered user
                            $check = $db->prepare("SELECT `id`,`username`, `email`,`password` FROM `company_login` WHERE `email`=?");
                            $check->execute(array($_POST['login_email']));
    
                            if($check->rowCount()>0){
                                if($result=$check->fetch()){
                                    // password verification
                                    // if(true){
                                    $pswd = $_POST['login_password'];
                                    if(password_verify($pswd, $result['password'])){
                                        
                                        // redirect to homepage
                                        header("location:../add-vacancy/company-add-job.php");
                                    } else {
                                        $msg2.="Password you entered is incorrect <br>";
                                    }
                                }
                            } else $msg2.="Email address you entered is not registered <br>";
                        } catch (PDOException $e){
                            $msg.=$e->getMessage();
                            echo $e;
                        }
                    }

                }
                
            }

        ?>

</head>
<body>
    <header class="header">
        <a href="#"class="logo">JOB VACANCY <span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:2;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php" >Home</a>
            <a href="\my_project\job-vecancy\campany\job-type\job-type.php">Job Type</a>
           <a href="\my_project\job-vecancy\campany\login\company-login.php"class="active">Company Login</a>
           <a href="#">Contact</a>

           <span class="active-nav"></span>
          <span class="animate" style="--i:3;">
        </nav>
    </header>

 <div class="wrapper">   


<div class="form-box">
        
        <!------------------- login form -------------------------->

         <div class="login-container" id="login">
            <div class="top">
                <span>Don't have an account? <a href="#" onclick="register()">Sign Up</a></span>
                <header>Login</header>
            </div>
        <form method="POST" action=""> 

        <?php if(isset($okmsg)) echo '<div id="okmsg">',$okmsg,'</div>'; ?>
                        <?php if($msg2!="") echo $msg2; ?>

            <div class="input-box">
                <input type="text"  name="login_email" class="input-field" placeholder="Username or Email" value="<?php if(isset($_POST['login_email'])) echo $_POST['login_email']; ?>">
                <i class="bx bx-user"></i>
            </div>
            <div class="input-box">
                <input type="password"name="login_password" class="input-field" placeholder="Password">
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit" name="sent" value="Sign In">
            </div>
            <div class="two-col">
                <div class="one">
                    <input type="checkbox" id="login-check">
                    <label for="login-check"> Remember Me</label>
                </div>
                <div class="two">
                    <label><a href="#">Forgot password?</a></label>
                </div>
            </div>
            </form>
        </div>

        <!------------------- registration form -------------------------->
        <div class="register-container" id="register">
            <div class="top">
                <span>Have an account? <a href="#" onclick="login()">Login</a></span>
                <header>Sign Up</header>
            </div>

            <form method="POST" action="">

            <?php if(isset($okmsg1)) echo '<div id="okmsg">',$okmsg1,'</div>'; ?>
                        <?php 
                            if($msg1!="") {
                                echo $msg1;
                            } 
                        ?>

            <div class="two-forms">
                <div class="input-box">
                    <input type="text" class="input-field" placeholder="name" name="name" value="<?php if(isset($_POST['name'])) echo $_POST['name']; ?>">
                    <i class="bx bx-user"></i>
                </div>
                <div class="input-box">
                    <input type="email" class="input-field" placeholder="email" name="gmail" value="<?php if(isset($_POST['gmail'])) echo $_POST['gmail']; ?>">
                    <i class="bx bx-user"></i>
                </div>
            </div>
            <div class="input-box">
                <input type="password" class="input-field" placeholder="password" name="password">
                <i class="bx bx-envelope"></i>
            </div>
            <div class="input-box">
                <input type="password" name="password2" class="input-field" placeholder="comfirm Password">
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit"  name="sent" value="REGISTER">
            </div>
            <div class="two-col">
                <div class="one">
                    <input type="checkbox" id="register-check">
                    <label for="register-check"> Remember Me</label>
                </div>
                <div class="two">
                    <label><a href="#">Terms & conditions</a></label>
                </div>
            </div>
        </form>
        </div>
    </div>
</div>   

<script src="script.js"></script>

<script>
   
   function myMenuFunction() {
    var i = document.getElementById("navMenu");

    if(i.className === "nav-menu") {
        i.className += " responsive";
    } else {
        i.className = "nav-menu";
    }
   }
 
</script>

<script>

    var a = document.getElementById("loginBtn");
    var b = document.getElementById("registerBtn");
    var x = document.getElementById("login");
    var y = document.getElementById("register");

    function login() {
        x.style.left = "4px";
        y.style.right = "-520px";
        a.className += " white-btn";
        b.className = "btn";
        x.style.opacity = 1;
        y.style.opacity = 0;
    }

    function register() {
        x.style.left = "-510px";
        y.style.right = "5px";
        a.className = "btn";
        b.className += " white-btn";
        x.style.opacity = 0;
        y.style.opacity = 1;
    }

</script>


</body>
</html>