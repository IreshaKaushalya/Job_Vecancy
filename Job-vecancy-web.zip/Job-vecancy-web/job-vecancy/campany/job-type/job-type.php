<!DOCTYPE html>
<html lang="en">
 
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>JOB VACANCY</title>
    <!-- SwiperJS CDN -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="job-type.css" />
    
  </head>

  <body>

  <header class="header">
        <a href="#"class="logo">JOB VACANCY <span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:2;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">Home</a>
            <a href="\my_project\job-vecancy\campany\job-type\job-type.php" class="active">Job Type</a>
           <a href="\my_project\job-vecancy\campany\login\company-login.php">Company Login</a>
           <a href="">Contact</a>

           <span class="active-nav"></span>
          <span class="animate" style="--i:3;">
        </nav>
    </header>

    <div class="container">
      <!-- Side infos -->
      <div class="side-info">
            <span>JOBS</span>
            <h1>NEW JOBS</h1>
            <hr />
            <p>
                *To transform lives through
                the prevention and treatment of blindness.
            </p>
            
      </div>

      <!-- Swiper slider -->
      <div class="swiper">
        <div class="swiper-wrapper">
     
            <div class="swiper-slide slide-one">
                <div>
                      <h2>UX/UI Design </h2>
                      <p>
                          *❝SOMEONE AT THE BEGINNING OF THEIR CAREER IS 
                          GIVEN REAL RESPONSIBILITIES AND INTERESTING WORK
                          RIGHT FROM THE START.
                      </p>
                      <a href="\my_project\job-vecancy\campany\login\company-login.php">ADD JOB</a>
                </div>
          </div>
    
    
   
             <div class="swiper-slide slide-two">
                <div>
                <h2> Web Developer </h2>
                <p>
                    *❝SOMEONE AT THE BEGINNING OF THEIR CAREER IS 
                    GIVEN REAL RESPONSIBILITIES AND INTERESTING WORK
                    RIGHT FROM THE START.
                </p>
                <a href="\my_project\job-vecancy\campany\login\company-login.php">ADD JOB</a>
                </div>
          </div>
      
          <!-- Content 3 -->
          <div class="swiper-slide slide-three">
            <div>
              <h2>Database Administrator</h2>
              <p>
                *❝SOMEONE AT THE BEGINNING OF THEIR CAREER IS 
                GIVEN REAL RESPONSIBILITIES AND INTERESTING WORK
                 RIGHT FROM THE START.
              </p>
              <a href="\my_project\job-vecancy\campany\login\company-login.php">ADD JOB</a>
            </div>
          </div>
          <!-- Content 4 -->
          <div class="swiper-slide slide-four">
            <div>
              <h2>Software Developer</h2>
              <p>
                *❝SOMEONE AT THE BEGINNING OF THEIR CAREER IS 
                GIVEN REAL RESPONSIBILITIES AND INTERESTING WORK
                 RIGHT FROM THE START.
              </p>
              <a href="\my_project\job-vecancy\campany\login\company-login.php">ADD JOB</a>
            </div>
          </div>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      </div>
    </div>

    <?php include "footer.php"?>

    <!-- SwiperJS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

    <!-- Custom JS -->
    <script src="job-type.js"></script>
    <script src="script.js"></script>

  </body>
</html>
