<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
      
    <link rel="stylesheet" href="company-add-job.css">

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    
    <?php
      $msg="";

      if(isset($_POST['sent'])){
        try {
          // connect to db
          include "../../database.php";
      
           $ok = $db->prepare("INSERT INTO add_vacancy
           (`Cname`,`Jtype`,`colification`,`Start_date`,`End_date`,`Cmobile`,`email`) 
             VALUES (?,?,?,?,?,?,?)")->execute(array($_POST['name'], $_POST['type'], $_POST['colification'], $_POST['open'], $_POST['end'], $_POST['mobile'], $_POST['email']));
           
           
                if($ok) {
                   
                    header("location:../payment/payment.php");
                }
                 //else {
                   // $msg2.="Password you entered is incorrect <br>";
              //  }
            
          //  if($ok) {
           //     $okmsg = "Record is added successfully";
          //  }
          
        }catch (PDOException $e) {
          $msg.=$e->getMessage();
                       // echo $e;
        }
      }


    ?>



</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY</span><span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:1;"></span></div>

       <nav class="navbar">
       <a href="\my_project\job-vecancy\user\home\index.php">Home</a>
          <a href="\my_project\job-vecancy\campany\job-type\job-type.php">Job Type</a>
       <a href="\my_project\job-vecancy\campany\login\company-login.php">Login</a>
       <a href="\my_project\job-vecancy\campany\add-vacancy\company-add-job.php"class="active">Add Job</a>
      
         
          <span class="active-nav"></span>
          <span class="animate" style="--i:1;"></span>
         
        </nav>
        </header>
<section>
    <div class="company">
        <div class="promotext">
            <h3>welcome! </h3>
                <h3>back</h3>
                <p>add your vacancy in our web site and find <br> new works for your company
                </p>
        </div>

            <div class="application">
                <h4>ADD VACANCY </h4>
                <p>in your company</p>

                
                <form method="post">
                        
                        <?php if(isset($okmsg)) echo '<div id="okmsg">',$okmsg,'</div>'; ?>

                    <div class="register-box">
                        <div class="input">
                            <input type="text"name="name"required>
                                <span>Capany Name : </span>
                        </div>
                    </div>

                    <div class="register-box">
                        <div class="input">
                            <input type="text"name="type"required>
                                <span>Job Type :</span>
                        </div>
                    </div>

                    <div class="register-box">
                        <div class="input">
                            <input type="date"name="open"required>
                                <span>Open : </span>
                        </div>
                    </div>

                    <div class="register-box">
                        <div class="input">
                            <input type="date" name="end"required>
                                <span>End Date :</span>
                        </div>
                    </div>

                    <div class="register-box">
                        <div class="input">
                            <input type="number"name="mobile"required>
                                <span>Telephone :</span>
                        </div>
                    </div>
                
                    <div class="register-box">
                        <div class="input">
                            <input type="email"name="email"required>
                                <span>Email :</span>
                        </div>
                    </div>

                        
                    <div class="register-box">
                        <div class="input">
                            <p class="text-p">Colification :</p>
                     <textarea name="colification" id="" cols="30" rows="10"required></textarea>
                                
                        </div>
                    </div>
                     

                    <div class="btn-box btns">
                        <button type="submit" name="sent" class="btn">submit</button>
                    </div>
                </form>
                    
            </div>
    </div>
</section>

<script src="script.js"></script>

</body>
    
</html>