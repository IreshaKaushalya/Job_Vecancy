<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- custom css file -->
    <link rel="stylesheet" href="index.css">
</head>
<body>

    
    <!-- header section starts -->

    <header class="header">

        <a href="#" class="logo">
            <img src="\my_project\job-vecancy\user\img\logo.png" alt="">
        </a>

        <nav class="navbar">
            <div id="close" class="fas fa-times"></div>

            <a href="\my_project\job-vecancy\user\home\index.php"  class="nav_item">home</a>
            <a href="\my_project\job-vecancy\user\signin\singin.php" class="nav_item">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php" class="nav_item">View Jobs</a>
           <a href="\my_project\job-vecancy\user\login\login.php" class="nav_item">Apply jobs</a>
           <a href="\my_project\job-vecancy\user\contact\contact.php" class="nav_item">Contact</a>

        </nav>

        <div id="menu" class="fas fa-bars"></div>

    </header>

    <!-- header section ends -->
   
    <!-- home section starts -->

    <section class="home">

        <div class="content">
            <h1 class="title">New <span>job </span>opportunity<span> IT side</span> </h1>
            <p class="description"> With Our Network Of Partners, We Mentor, Train And Inspire <br> Local Teams So 
                They Can Save Sight In Their Communities.</p>
            <a href="\my_project\job-vecancy\user\signin\singin.php" class="btn">get started</a>
        </div>

        <div class="image">
            <img src="\my_project\job-vecancy\user\img\meeting.png" alt="" data-speed="-3" class="move">
        </div>

    </section>

    <?php include "footer.php"?>


  
    <!-- GSAP CDN Link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>

    <!-- custom js file -->
    <script src="index.js"></script>
</body>
</html>