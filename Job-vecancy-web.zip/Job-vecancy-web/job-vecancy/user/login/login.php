<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
    <link rel="stylesheet" href="login.css">
    
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>


                       
    <?php
                    $msg1="";
                    $msg2="";

            if(isset($_POST['sent'])){

                // registration form
                if($_POST['sent']=="REGISTER"){
                    // user name validation
                    $_POST['name'] = htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8');
                    if(empty($_POST['name'])) $msg1.="Your name cannot be empty <br>";

                    // email validation
                    $_POST['gmail'] = trim($_POST['gmail']);
                    if(empty($_POST['gmail'])) $msg1.="Email cannot be empty <br>";
                    elseif(!filter_var($_POST['gmail'],FILTER_VALIDATE_EMAIL)) $msg1.="Email address it not valid <br>";

                    // password validation
                    if(empty($_POST['password']) || empty($_POST['password2'])) $msg1.="Passwords cannot be empty <br>";
                    elseif($_POST['password']!=$_POST['password2']) $msg1.="Passwords do not match <br>";
                    

                    // db operations
                    if($msg1==""){
                        try {
                            // connect to db
                            include "../../database.php";
    
                            // check for existing email
                            $check = $db->prepare("SELECT `id` FROM `user_login` WHERE `email`=?");
                            $check->execute(array($_POST['gmail']));
    
                            if($check->rowCount()>0) {
                            $msg1.="Email address you entered is registered already(php)<br>";
                            }
                            else{
                                // insert user
                                $pwd = password_hash($_POST['password'],PASSWORD_DEFAULT);
                                
                                $ok = $db->prepare("INSERT INTO `user_login` (`username`, `email`, `password`) VALUES (?,?,?)")->execute(array($_POST['name'], $_POST['gmail'], $pwd));

                                $okmsg1 = "Record is added successfully";

                            }

                        } catch (PDOException $e) {
                            $msg1.=$e->getMessage();
    
                                        // echo $e;
                        }

                    }

                    
                }

                // login form
                elseif($_POST['sent']=="LOGIN"){
                    // email validation
                    $_POST['login_email'] = trim($_POST['login_email']);
                    if(empty($_POST['login_email'])) $msg2.="Email cannot be empty <br>";
                    elseif(!filter_var($_POST['login_email'],FILTER_VALIDATE_EMAIL)) $msg.="Email address it not valid (php**)<br>";
    
                    // password validation
                    if(empty($_POST['login_password'])) 
                    $msg2.="Password cannot be empty <br>";
    
                    // db operations
                    //if(true){
                    if($msg2==""){
                        try{
                            //connect to db
                            include "../../database.php";
    
                            // check for a registered user
                            $check = $db->prepare("SELECT `id`,`username`, `email`,`password` FROM `user_login` WHERE `email`=?");
                            $check->execute(array($_POST['login_email']));
    
                            if($check->rowCount()>0){
                                if($result=$check->fetch()){
                                    // password verification
                                    // if(true){
                                    $pswd = $_POST['login_password'];
                                    if(password_verify($pswd, $result['password'])){
                                        
                                        // redirect to homepage
                                        header("location:../application/application.php");
                                    } else {
                                        $msg2.="Password you entered is incorrect <br>";
                                    }
                                }
                            } else $msg2.="Email address you entered is not registered <br>";
                        }catch (PDOException $e){
                            $msg.=$e->getMessage();
                            echo $e;
                        }
                    }

                }
                
            }

        ?>

</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY</span><span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:1;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">home</a>            
            <a href="\my_project\job-vecancy\user\signin\singin.php">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php">View Jobs</a>
           <a href="\my_project\job-vecancy\user\login\login.php" class="active">Login</a>
           <a href="\my_project\job-vecancy\user\contact\contact.php">Contact</a>
         
          <span class="active-nav"></span>
          <span class="animate" style="--i:1;"></span>
         
        </nav>
    </header>
    
    <div class="wrapper">
        <span class="bg-animate"></span>
        <span class="bg-animate2"></span>

                     <!--------Login-------->
        <div class="form-box login">
            <h2 class="animation1" style="--i:0; --j:21;">Login</h2>

            <form method="POST"  action="#">

            
            <?php if(isset($okmsg)) echo '<div id="okmsg">',$okmsg,'</div>'; ?>
                <?php if($msg2!="") echo $msg2; ?>


                <div class="input-box animation1" style="--i:1; --j:22;">
                    <input type="text"name="login_email" value="<?php if(isset($_POST['login_email'])) echo $_POST['login_email']; ?>" required>
                    <label>User name</label>
                    <i class='bx bx-user-circle'></i>
                </div>

                <div class="input-box animation1" style="--i:2; --j:23;">
                    <input type="password" name="login_password" required>
                    <label>password</label>
                    <i class='bx bxs-lock-alt' ></i>
                </div>

                <button type="submit" name="sent" value="LOGIN"  class="btn animation1" style="--i:3; --j:24;">Login
                </button>

                <div class="logreg-link animation1" style="--i:4; --j:25;">
                    <p>Don't have an account ? <a href="#"
                         class="register-link">Sign up
                    </a></p>
                </div>
            </form>
        </div>


          <!--------register-------->

        <div class="info-text login">
            <h2 class="animation1" style="--i:0; --j:20;">Welcome Back</h2>
            <p class="animation1" style="--i:1; --j:21;">We aim to recruit, develop and retain a highly motivated, skilled and diverse workforce.
            </p>
        </div>


        
        <div class="form-box register">
            <h2 class="animation1" style="--i:17; --j:0;">sign up</h2>

            <form method="POST"  action="#">

            <?php if(isset($okmsg1)) echo '<div id="okmsg">',$okmsg1,'</div>'; ?>
                        <?php 
                            if($msg1!="") {
                                echo $msg1;
                            } 
                        ?>

                <div class="input-box animation1" style="--i:18; --j:1;">
                    <input type="text" name="name" value="<?php if(isset($_POST['name'])) echo $_POST['name']; ?>" required>
                    <label>User name</label>
                    <i class='bx bx-user-circle'></i>
                </div>

                <div class="input-box animation1"style="--i:19; --j:2;">
                    <input type="text" name="gmail" value="<?php if(isset($_POST['gmail'])) echo $_POST['gmail']; ?>" required>
                    <label>email</label>
                    <i class='bx bxs-envelope'></i>
                </div>

                <div class="input-box animation1"style="--i:20; --j:3;">
                    <input type="password" name="password" required>
                    <label>password</label>
                    <i class='bx bxs-lock-alt' ></i>
                </div>

                <div class="input-box animation1"style="--i:20; --j:3;">
                    <input type="password" name="password2" required>
                    <label>Comfirm Password</label>
                    <i class='bx bxs-lock-alt' ></i>
                </div>

                <button type="submit" name="sent" value="REGISTER" class="btn animation1"style="--i:21; --j:4;">sign up
                </button>

                <div class="logreg-link animation1"style="--i:22; --j:5;">
                    <p>Already have an account ? <a href=""
                         class="Login-link">login
                    </a></p>
                </div>
            </form>
        </div>

                
        <div class="info-text register">
            <h2 class="animation1" style="--i:17; --j:0;">Welcome Back</h2>
            <p class="animation1" style="--i:18; --j:1;">We aim to recruit, develop and retain a highly motivated, skilled and diverse workforce.
            </p>
        </div>

    </div>



    <script src="script.js"></script>
    <script src="login.js"></script>
    
</body>
</html>