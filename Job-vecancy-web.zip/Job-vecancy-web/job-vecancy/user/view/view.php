<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
   
    <link rel="stylesheet" href="view.css">

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY</span><span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:2;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">home</a>            
            <a href="\my_project\job-vecancy\user\signin\singin.php">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php" class="active">View Jobs</a>
            <a href="\my_project\job-vecancy\user\login\login.php">Apply jobs</a>
            <a href="\my_project\job-vecancy\user\contact\contact.php">Contact</a>
         
        
          <span class="active-nav"></span>
          <span class="animate" style="--i:3;"></span>
         
        </nav>
    </header>

    <section class="education" id="education">
     <h2 class="heading">our<span>journey</span></h2>

        <div class="education-row">
            <div class="education-column">
               <!--- <h3 class="title">expiriyas</h3>---> 

                <div class="education-box">
                   <div class="education-content">
                    <a href="\my_project\job-vecancy\user\login\login.php">
                        <div class="content">
                           <div class="year"><i class='bx bxs-calendar'></i>20/05/2020 - 20/06/2020</div>
                                     <h3 class="contentH3"><!--Software Developer-->Xiteb Pvt Ltd </h3>
                                       <p class="contentP"> <b>Position:</b> &nbsp; Software Developer <br>
                                            <b> Address:</b>&nbsp; 123 2/1, 2nd Floor,<br> McLarens Building, <br>
                                             Bauddhaloka Mw Colombo 4, <br><br>
                                            <b>Phone: </b> &nbsp;0114 347 575<br>
                                            <b>Email:</b>  &nbsp;XitebPvtLtd@gmail.com. 
                                        </p>
                                    
                                    </a>
                        </div>
                     </div>

                     <div class="education-content">
                        <a href="\my_project\job-vecancy\user\login\login.php">
                            <div class="content">
                               <div class="year"><i class='bx bxs-calendar'></i>02/06/2020-20/07/2020</div>
                                 <h3 class="contentH3">Phyxle</h3>
                                <p class="contentP">
                                <b>Position:</b> &nbsp; Web Developer  <br>
                                <b>Address:</b>&nbsp; 5 Charles Pl, <br>
                                 Colombo 00300<br><br>
                                <b>Phone: </b> &nbsp; 071 207 7000<br>
                                <b>Email:</b>  &nbsp;phyxle@gmail.com. 
                            </p></a>
                            </div>
                     </div>

                     <div class="education-content">
                        <a href="\my_project\job-vecancy\user\login\login.php">
                            <div class="content">
                               <div class="year"><i class='bx bxs-calendar'></i>01/7/2020-31/07/2020</div>
                                 <h3 class="contentH3"> Tectera</h3>
                                 <p class="contentP">
                                <b>Position:</b> &nbsp; Web design <br>
                                <b>Address:</b>&nbsp; 30 5/1 Nelson Pl, <br>
                                 Colombo 00600<br><br>
                                <b>Phone: </b> &nbsp;077 433 2205<br>
                                <b>Email:</b>  &nbsp;tectera@gmail.com. 
                            </p></a>
                            </div>
                     </div>

                </div>                
            </div>

            <div class="education-column">
               <!---- <h3 class="title">education</h3>--->

                <div class="education-box">
                    <div class="education-content">
                        <a href="\my_project\job-vecancy\user\login\login.php">
                            <div class="content">
                               <div class="year"><i class='bx bxs-calendar'></i>20/01/2021-10/02/2021</div>
                                <h3 class="contentH3">Media Mania.</h3>
                                <p class="contentP">
                                <b>Position:</b> &nbsp; Social Media Manager  <br>
                                <b>Address:</b>&nbsp;  Abu Dhabi, Twofour54,<br>
                                 Yas Creative Hub, Tower 4<br><br>
                                <b>Phone: </b> &nbsp;071 2 886 4649<br>
                                <b>Email:</b>  &nbsp;Mania@gmail.com. 
                            </p></a>
                            </div>
                     </div>

                     <div class="education-content">
                        <a href="\my_project\job-vecancy\user\login\login.php">
                            <div class="content">
                               <div class="year"><i class='bx bxs-calendar'></i>18/02/2022-20/03/2022</div>
                                 <h3 class="contentH3"> ODDLY</h3>
                                <p class="contentP"> 
                                <b>Position:</b> &nbsp; UX/UI Design  <br>
                                <b>Address:</b>&nbsp; 1st Floor, No 15, Station <br>
                                 Road, 03, 00300<br><br>
                                <b>Phone: </b> &nbsp;072 199 9949<br>
                                <b>Email:</b>  &nbsp;oddly@gmail.com. 
                            </p></a>
                            </div>
                     </div>

                   <div class="education-content">
                    <a href="\my_project\job-vecancy\user\login\login.php">
                        <div class="content">
                           <div class="year"><i class='bx bxs-calendar'></i>06/02/2023-02/3/2023</div>
                            <h3 class="contentH3">National Drug Quality <br>
                             Assurance Laboratory </h3>
                            <p class="contentP">
                            <b>Position:</b> &nbsp;Quality Assurance  <br>
                            <b>Address:</b>&nbsp; WVC8+2F3, Norris Canal Rd, <br>
                             Colombo 01000<br><br>
                            <b>Phone: </b> &nbsp;0112 687 743<br>
                            <b>Email:</b>  &nbsp;ndqal@gmail.com. 
                        </p></a>
                        </div>
                     </div>
                </div>                
            </div>

        </div>
    </section>

    <?php include "footer.php"?>

    <script src="script.js"></script>
</body>
</html>