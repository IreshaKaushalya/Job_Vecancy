<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
    <link rel="stylesheet" href="signin.css">   
   

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY <span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:2;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">home</a>            
            <a href="\my_project\job-vecancy\user\signin\singin.php" class="active">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php">View Jobs</a>
            <a href="\my_project\job-vecancy\user\login\login.php">Apply jobs</a>
            <a href="\my_project\job-vecancy\user\contact\contact.php">Contact</a>
         

           <span class="active-nav"></span>
          <span class="animate" style="--i:3;">
        </nav>
    </header>

    <section class="about" id="about">
        <h2 class="heading">sign <span>in</span></h2>

        <div class="about-img">
            <img src="\my_project\job-vecancy\user\img\2.webp" alt="">
            <span class="circle-spin"></span>
        </div>

       
    <div class="about-content">
        <h3>your can</h3>
        <p>SOMEONE AT THE BEGINNING OF THEIR CAREER IS GIVEN REAL 
            RESPONSIBILITIES 
            AND INTERESTING WORK RIGHT FROM THE START.
        </p>

        <div class="btn-box btns">
            <a href="\my_project\job-vecancy\user\view\view.php" class="btn">APPLY JOBS</a>
            <a href="\my_project\job-vecancy\campany\job-type\job-type.php" class="btn">ADD VACANCY</a>            
        </div>
    </div>
    </section>
    
    <?php include "footer.php"?>

    <script src="script.js"></script>
</body>
</html>