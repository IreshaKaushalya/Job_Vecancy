<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- custom css file -->
    <link rel="stylesheet" href="application.css">

    <?php
      $msg="";

      if(isset($_POST['sent'])){
        try {
          // connect to db
          include "../../database.php";
      
          $ok = $db->prepare("INSERT INTO user_application
          (`Username`,`Uage`,`Ubirth`,`UID`,`Uschool`,`UhomeTown`,`Gender`, `Jtype`,`Uphone`,`Uemail`,`message`) 
          VALUES (?,?,?,?,?,?,?,?,?,?,?)")->execute(array($_POST['Username'], $_POST['Uage'],
          $_POST['Ubirth'], $_POST['UID'], $_POST['Uschool'], $_POST['UhomeTown'], $_POST['Gender']
          , $_POST['Jtype'], $_POST['Uphone'], $_POST['Uemail'], $_POST['message']));

   
            if($ok) {
                $okmsg = "Record is added successfully";
            }
          
        }catch (PDOException $e) {
          $msg.=$e->getMessage();
                        // echo $e;
        }
      }


    ?>
    
</head>
<body>
</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY <span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:2;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">home</a>
            <a href="\my_project\job-vecancy\user\signin\singin.php">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php">View Jobs</a>
           <a href="\my_project\job-vecancy\user\login\login.php">Login</a>
           <a href="\my_project\job-vecancy\user\application\application.php" class="active">Apply jobs</a>
           <a href="\my_project\job-vecancy\user\contact\contact.php">Contact</a>

           <span class="active-nav"></span>
          <span class="animate" style="--i:3;">
        </nav>
    </header>


    <div class="application">
        <span class="big-circle"></span>
        <img src="\my_project\job-vecancy\user\img\shape.png" class="square" alt="" />
        <div class="form">
          <div class="contact-info">
            <h3 class="title">APPLICATION</h3>
            <p class="text">We offer you a responsible job with the ability to work independently in a
               technologically leading company in an innovative and dynamic environment as well as
                performance-related remuneration and opportunities for further training.
             
            </p>
  
            <div class="info">
              <div class="information">
                <img src="\my_project\job-vecancy\user\img\location.png" class="icon" alt="" />
                <p>92 Cherry Drive Uniondale, NY 11553</p>
              </div>
              <div class="information">
                <img src="\my_project\job-vecancy\user\img\email.png" class="icon" alt="" />
                <p>lorem@ipsum.com</p>
              </div>
              <div class="information">
                <img src="\my_project\job-vecancy\user\img\phone.png" class="icon" alt="" />
                <p>123-456-789</p>
              </div>
            </div>
  
            
          </div>
  
          <div class="contact-form">
            <span class="circle one"></span>
            <span class="circle two"></span>
  
            <form method="post" action="#" autocomplete="off">

            <?php if(isset($okmsg)) echo '<div id="okmsg">',$okmsg,'</div>'; ?>

              <h3 class="title">Apply Now</h3>
             
              <div class="input-application">
                <input type="text" name="Username" class="input" required />
                <label for="">Name</label>
                <span>Name</span>
              </div>


              <div class="input-application">
                <input type="number" name="Uage" class="input" required />
                <label for="">Age</label>
                <span>Age</span>
              </div>

              
              <div class="input-application">
                <input type="date" name="Ubirth" class="input" required />
                <label for="">Birth</label>
                <span>Birth</span>
              </div>

              <div class="input-application">
                <input type="number" name="UID" class="input" required/>
                <label for="">ID</label>
                <span>ID</span>
              </div>

              <div class="input-application">
                <input type="text" name="Uschool" class="input" required/>
                <label for="">School</label>
                <span>School</span>
              </div>

              <div class="input-application">
                <input type="text" name="UhomeTown" class="input" required />
                <label for="">Home Town</label>
                <span>Home Town</span>
              </div>


              <div class="input-application">
                <input type="text" name="Gender" class="input" required/>
                <label for="">Gender</label>
                <span>Gender</span>
              </div>

              <div class="input-application">
                <input type="text" name="Jtype" class="input" required />
                <label for="">Job Type</label>
                <span>Job Type</span>
              </div>

              
              <div class="input-application">
                <input type="tel" name="Uphone" class="input" required />
                <label for="">Phone</label>
                <span>Phone</span>
              </div>


              <div class="input-application">
                <input type="email" name="Uemail" class="input" required />
                <label for="">Email</label>
                <span>Email</span>
              </div>


                

              <div class="input-application textarea">
                <textarea name="message" class="input"required></textarea>
                <label for="">Colification</label>
                <span>Colification</span>
              </div>
              <div class="btn-box btns">
                    <button type="submit" name="sent" class="btn">submit</button>
                </div>
            </form>
          </div>
        </div>
      </div>

    <?php include "footer.php"?>

      <script src="script.js"></script>
      <script src="app.js"></script>
</body>
</html>