<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB VACANCY</title>
    
    <link rel="stylesheet" href="contact.css">   
   
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  
    <?php
      $msg="";

      if(isset($_POST['sent'])){
        try {
          // connect to db
          include "../../database.php";
      
           $ok = $db->prepare("INSERT INTO contact (`Name`,`email`, `phone`,`mail_subject`,`Message`) VALUES (?,?,?,?,?)")->execute(array($_POST['Name'], $_POST['email'], $_POST['phone'], $_POST['mail_subject'], $_POST['Message']));

 
            if($ok) {
                $okmsg = "Record is added successfully";
            }
          
        }catch (PDOException $e) {
          $msg.=$e->getMessage();
                    
        }
      }


    ?>
</head>
<body>

    <header class="header">
        <a href="#"class="logo">JOB VACANCY</span><span class="animate" style="--i:1;"></span></a>

        <div class="bx bx-menu" id="menu-icon"></span><span class="animate" style="--i:1;"></span></div>

       <nav class="navbar">
            <a href="\my_project\job-vecancy\user\home\index.php">home</a>            
            <a href="\my_project\job-vecancy\user\signin\singin.php">Sign in</a>
            <a href="\my_project\job-vecancy\user\view\view.php">View Jobs</a>
            <a href="\my_project\job-vecancy\user\login\login.php">Apply jobs</a>
            <a href="\my_project\job-vecancy\user\contact\contact.php" class="active">Contact</a>
         
          <span class="active-nav"></span>
          <span class="animate" style="--i:1;"></span>
         
        </nav>
    </header>

    <section class="contact" id="contact">
        <h2 class="heading1">contact <span>me!</span></h2>

            
        <form method="post" action="#">

        <?php if(isset($okmsg)) echo '<div id="okmsg">',$okmsg,'</div>'; ?>

            <div class="input-box">
                <div class="input-field">
                    <input type="text"name="Name" placeholder="Full Name" required>
                    <span class="focus"></span>
                </div>

                <div class="input-field">
                    <input type="text"name="email" placeholder="Email Address" required>
                    <span class="focus"></span>
                </div>
            </div>

            <div class="input-box">
                <div class="input-field">
                    <input type="number" name="phone" placeholder="Mobail Number" required>
                    <span class="focus"></span>
                </div>

                <div class="input-field">
                    <input type="text" name="mail_subject"placeholder="Email Subject" required>
                    <span class="focus"></span>
                </div>
            </div>
            <div class="input-box1">
                <div class="textarea-field">
                    <textarea name="Message" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
                    <span class="focus"></span>
                </div>
            </div>

                <div class="btn-box btns">
                    <button type="submit" name="sent" class="btn">submit</button>
                </div>
        </form>

    </section>

    <?php include "footer.php"?>

    <script src="script.js"></script>
</body>
</html>